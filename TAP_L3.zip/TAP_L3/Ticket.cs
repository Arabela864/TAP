using System;

public enum TicketStatus 
{ 
    New, Assigned, DiagnosticsProvided, DiagnosticsAccepted, Paid, Closed 
}

public class Ticket 
{
    private decimal _price;

    public int Id { get; private set; }
    public string Description { get; private set; }
    public string DiagnosticsReport { get; private set; }
    public TicketStatus Status { get; private set; }
    public string CustomerName { get; private set; }
    public string OperatorName { get; private set; }

    public decimal Price 
    {
        get { return _price; }
        private set 
        {
            if (value < 0) throw new ArgumentException("Prețul nu poate fi negativ.");
            _price = value;
        }
    }

    public Ticket(int id, string description, string customerName) 
    {
        Id = id;
        Description = description;
        CustomerName = customerName;
        Status = TicketStatus.New;
    }

    public void AssignOperator(string operatorName) 
    {
        OperatorName = operatorName;
        Status = TicketStatus.Assigned;
    }

    public void AddDiagnostics(string report, decimal price) 
    {
        DiagnosticsReport = report;
        Price = price;
        Status = TicketStatus.DiagnosticsProvided;
    }

    public void AcceptDiagnostics() 
    {
        Status = TicketStatus.DiagnosticsAccepted;
    }

    public void MarkAsPaid() 
    {
        Status = TicketStatus.Paid;
    }

    public void Close() 
    {
        Status = TicketStatus.Closed;
    }
}