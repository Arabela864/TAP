﻿using System;

class Program 
{
    static void Main(string[] args) 
    {
        RegularUser client = new RegularUser("Alex");
        OperatorUser tehnician = new OperatorUser("Maria");
        IPaymentProcessor procesorPlata = new CardPaymentProcessor(); 

        Console.WriteLine("--- start---\n");

        Ticket tichetLaptop = client.CreateTicket(101, "Ecranul laptopului nu se aprinde.");
        tehnician.AssignToTicket(tichetLaptop);
        tehnician.ProvideDiagnosticsReport(tichetLaptop, "Display defect. Necesită înlocuire panou LCD.", 450.00m);
        client.AcceptDiagnosticsReport(tichetLaptop);
        client.PayServices(tichetLaptop, procesorPlata);
        tehnician.CloseTicket(tichetLaptop);

        Console.WriteLine($"\nStare finală tichet: {tichetLaptop.Status}");
    }
}