using System;

public abstract class User 
{
    public string Name { get; protected set; }

    protected User(string name) 
    {
        Name = name;
    }
}

public class RegularUser : User 
{
    public RegularUser(string name) : base(name) { }

    public Ticket CreateTicket(int ticketId, string problemDescription) 
    {
        Console.WriteLine($"{Name} a creat tichetul #{ticketId}: {problemDescription}");
        return new Ticket(ticketId, problemDescription, Name);
    }

    public void AcceptDiagnosticsReport(Ticket ticket) 
    {
        if (ticket.Status == TicketStatus.DiagnosticsProvided && ticket.CustomerName == Name) 
        {
            ticket.AcceptDiagnostics();
            Console.WriteLine($"{Name} a acceptat diagnosticul: '{ticket.DiagnosticsReport}' pentru {ticket.Price} RON.");
        }
    }

    public void PayServices(Ticket ticket, IPaymentProcessor paymentProcessor) 
    {
        if (ticket.Status == TicketStatus.DiagnosticsAccepted) 
        {
            bool success = paymentProcessor.ProcessPayment(ticket.Price);
            if (success) 
            {
                ticket.MarkAsPaid();
                Console.WriteLine($"{Name} a plătit cu succes tichetul #{ticket.Id}.");
            }
        }
    }
}

public class OperatorUser : User 
{
    public OperatorUser(string name) : base(name) { }

    public void AssignToTicket(Ticket ticket) 
    {
        if (ticket.Status == TicketStatus.New) 
        {
            ticket.AssignOperator(Name);
            Console.WriteLine($"Operatorul {Name} a preluat tichetul #{ticket.Id}.");
        }
    }

    public void ProvideDiagnosticsReport(Ticket ticket, string report, decimal price) 
    {
        if (ticket.Status == TicketStatus.Assigned && ticket.OperatorName == Name) 
        {
            ticket.AddDiagnostics(report, price);
            Console.WriteLine($"Operatorul {Name} a oferit diagnosticul pentru tichetul #{ticket.Id}.");
        }
    }

    public void CloseTicket(Ticket ticket) 
    {
        if (ticket.Status == TicketStatus.Paid && ticket.OperatorName == Name) 
        {
            ticket.Close();
            Console.WriteLine($"Operatorul {Name} a închis tichetul #{ticket.Id}.");
        }
    }
}