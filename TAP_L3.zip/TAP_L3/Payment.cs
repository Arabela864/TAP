using System;

public interface IPaymentProcessor 
{
    bool ProcessPayment(decimal amount);
}

public class CardPaymentProcessor : IPaymentProcessor 
{
    public bool ProcessPayment(decimal amount) 
    {
        Console.WriteLine($"[Sistem de Plată] Procesez plata în valoare de {amount} RON... Aprobat!");
        return true;
    }
}