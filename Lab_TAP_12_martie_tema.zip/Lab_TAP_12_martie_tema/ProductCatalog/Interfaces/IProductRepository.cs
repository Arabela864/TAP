using ProductCatalog.Models;

namespace ProductCatalog.Interfaces;

public interface IProductRepository
{
    IQueryable<Product> GetAllAsQueryable();
}