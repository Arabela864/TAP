using ProductCatalog.Models;

namespace ProductCatalog.Interfaces;

public interface IProductSearchService
{
    IEnumerable<Product> SearchProducts(ProductSearchCriteria criteria);
    IEnumerable<ProductGroupDto> GetProductsGroupedByCategory(ProductSearchCriteria criteria);
}