namespace ProductCatalog.Models;

public class ProductSearchCriteria
{
    public string? Category { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    
    public string? OrderBy { get; set; } 
    public bool IsDescending { get; set; } = false;

    
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 10;
}