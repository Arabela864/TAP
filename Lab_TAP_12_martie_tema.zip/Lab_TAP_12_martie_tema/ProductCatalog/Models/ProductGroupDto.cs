namespace ProductCatalog.Models;

public class ProductGroupDto
{
    public string Category { get; set; } = string.Empty;
    public int ProductCount { get; set; }
    public IEnumerable<Product> Products { get; set; } = new List<Product>();
}