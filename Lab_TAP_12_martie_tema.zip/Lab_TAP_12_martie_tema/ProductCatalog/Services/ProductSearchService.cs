using ProductCatalog.Interfaces;
using ProductCatalog.Models;

namespace ProductCatalog.Services;

public class ProductSearchService : IProductSearchService
{
    private readonly IProductRepository _repository;

    public ProductSearchService(IProductRepository repository)
    {
        _repository = repository;
    }

    public IEnumerable<Product> SearchProducts(ProductSearchCriteria criteria)
    {
        var query = _repository.GetAllAsQueryable();

        
        if (!string.IsNullOrEmpty(criteria.Category))
            query = query.Where(p => p.Category == criteria.Category);

        if (criteria.MinPrice.HasValue)
            query = query.Where(p => p.Price >= criteria.MinPrice.Value);

        if (criteria.MaxPrice.HasValue)
            query = query.Where(p => p.Price <= criteria.MaxPrice.Value);

        query = query.Where(p => p.IsActive);

        
        if (!string.IsNullOrEmpty(criteria.OrderBy))
        {
            query = criteria.OrderBy.ToLower() switch
            {
                "price" => criteria.IsDescending ? query.OrderByDescending(p => p.Price) : query.OrderBy(p => p.Price),
                "name" => criteria.IsDescending ? query.OrderByDescending(p => p.Name) : query.OrderBy(p => p.Name),
                _ => query.OrderBy(p => p.Id)
            };
        }
        else
        {
            query = query.OrderBy(p => p.Id);
        }

        
        query = query.Skip((criteria.PageNumber - 1) * criteria.PageSize).Take(criteria.PageSize);

        return query.ToList();
    }

    public IEnumerable<ProductGroupDto> GetProductsGroupedByCategory(ProductSearchCriteria criteria)
    {
        var filteredProducts = SearchProducts(criteria).AsQueryable();

       
        var groupedQuery = from product in filteredProducts
                           group product by product.Category into categoryGroup
                           orderby categoryGroup.Key
                           select new ProductGroupDto
                           {
                               Category = categoryGroup.Key,
                               ProductCount = categoryGroup.Count(),
                               Products = categoryGroup.ToList()
                           };

        return groupedQuery.ToList();
    }
}