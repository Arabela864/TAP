using ProductCatalog.Interfaces;
using ProductCatalog.Models;

namespace ProductCatalog.Repositories;

public class MockProductRepository : IProductRepository
{
    public IQueryable<Product> GetAllAsQueryable()
    {
        
        var products = new List<Product>
        {
            new Product { Id = 1, Name = "Laptop Dell", Category = "IT", Price = 3500m, IsActive = true },
            new Product { Id = 2, Name = "Mouse Logitech", Category = "IT", Price = 150m, IsActive = true },
            new Product { Id = 3, Name = "Telefon Samsung", Category = "Telefoane", Price = 4200m, IsActive = true },
            new Product { Id = 4, Name = "Casti Sony", Category = "Audio", Price = 800m, IsActive = true },
            new Product { Id = 5, Name = "Monitor LG", Category = "IT", Price = 1200m, IsActive = true },
            new Product { Id = 6, Name = "iPhone 13", Category = "Telefoane", Price = 3800m, IsActive = true },
            new Product { Id = 7, Name = "Telefon Vechi", Category = "Telefoane", Price = 500m, IsActive = false } 
        };

       
        return products.AsQueryable();
    }
}