﻿using ProductCatalog.Interfaces;
using ProductCatalog.Models;
using ProductCatalog.Repositories;
using ProductCatalog.Services;


IProductRepository repository = new MockProductRepository();
IProductSearchService searchService = new ProductSearchService(repository);


var criteria = new ProductSearchCriteria
{
    MinPrice = 100m,
    MaxPrice = 4000m, 
    OrderBy = "price",
    IsDescending = false, 
    PageNumber = 1,
    PageSize = 5 
};


Console.WriteLine("=== REZULTATE CĂUTARE SIMPLĂ ===");
var products = searchService.SearchProducts(criteria);

foreach (var p in products)
{
    Console.WriteLine($"[{p.Category}] {p.Name} - {p.Price} RON");
}

Console.WriteLine("\n=== REZULTATE GRUPATE PE CATEGORII ===");
var groupedProducts = searchService.GetProductsGroupedByCategory(criteria);

foreach (var group in groupedProducts)
{
    Console.WriteLine($"\nCategoria: {group.Category} ({group.ProductCount} produse)");
    foreach (var p in group.Products)
    {
        Console.WriteLine($"   -> {p.Name} - {p.Price} RON");
    }
}