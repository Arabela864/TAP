﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EcommerceSystem
{
    
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }

    public class CartItem
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }

    
    public interface IDiscountStrategy { double Apply(double total); }
    public class NoDiscount : IDiscountStrategy { public double Apply(double total) => total; }
    public class BlackFridayDiscount : IDiscountStrategy { public double Apply(double total) => total * 0.8; } // 20% reducere

    
    public interface IPaymentProcessor { void Process(double amount); }
    public class CardPayment : IPaymentProcessor { public void Process(double amount) => Console.WriteLine($"[Plată] S-au achitat {amount} RON prin Card."); }
    public class RevolutPayment : IPaymentProcessor { public void Process(double amount) => Console.WriteLine($"[Plată] S-au achitat {amount} RON prin Revolut."); }

    
    public interface IShippingService { void Ship(string address); }
    public class FanCourier : IShippingService { public void Ship(string address) => Console.WriteLine($"[Livrare] Coletul pleacă prin Fan Courier către: {address}"); }
    public class DHL : IShippingService { public void Ship(string address) => Console.WriteLine($"[Livrare] Coletul pleacă prin DHL către: {address}"); }

    
    public class Order
    {
        public List<CartItem> Items { get; set; } = new();
        public IDiscountStrategy Discount { get; set; } = new NoDiscount();
        public IPaymentProcessor Payment { get; set; }
        public IShippingService Shipping { get; set; }

        public void FinalizeOrder(string address)
        {
            double subtotal = Items.Sum(i => i.Product.Price * i.Quantity);
            double totalFinal = Discount.Apply(subtotal);

            Console.WriteLine("\n FACTURĂ ");
            Console.WriteLine($"Subtotal: {subtotal} RON");
            Console.WriteLine($"Total după discount: {totalFinal} RON");
            
            Payment.Process(totalFinal);
            Shipping.Ship(address);
            Console.WriteLine("\nComandă plasată cu succes!");
        }
    }

   
    class Program
    {
        static void Main(string[] args)
        {
            
            var catalog = new List<Product> {
                new Product { Id = 1, Name = "Laptop Dell", Price = 3500 },
                new Product { Id = 2, Name = "Mouse Logitech", Price = 150 },
                new Product { Id = 3, Name = "Tastatură Mecanică", Price = 450 }
            };

            Order currentOrder = new Order();
            
            Console.WriteLine(" E-Shop ");
            
            
            currentOrder.Items.Add(new CartItem { Product = catalog[0], Quantity = 1 });
            currentOrder.Items.Add(new CartItem { Product = catalog[1], Quantity = 2 });

            Console.WriteLine("Produse în coș: " + string.Join(", ", currentOrder.Items.Select(i => i.Product.Name)));

            
            Console.WriteLine("\nAlegeți metoda de plată (1: Card, 2: Revolut):");
            currentOrder.Payment = Console.ReadLine() == "2" ? new RevolutPayment() : new CardPayment();

            Console.WriteLine("Alegeți curierul (1: FanCourier, 2: DHL):");
            currentOrder.Shipping = Console.ReadLine() == "2" ? new DHL() : new FanCourier();

            Console.WriteLine("Aplicați cod discount? (DA pentru 20% reducere / NU):");
            if(Console.ReadLine()?.ToUpper() == "DA") currentOrder.Discount = new BlackFridayDiscount();

            
            currentOrder.FinalizeOrder("Str. General Berthelot nr. 16, Iași");
        }
    }
}