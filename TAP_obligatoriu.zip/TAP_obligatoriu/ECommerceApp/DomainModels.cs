namespace ECommerceApp;

public class Product {
    public string Name { get; set; } = "";
    public decimal Price { get; set; }
}

public class ShoppingCart {
    public List<(Product, int)> Items = new();
    public void AddProduct(Product p, int q) => Items.Add((p, q));
    public decimal GetTotal() => Items.Sum(i => i.Item1.Price * i.Item2);
}