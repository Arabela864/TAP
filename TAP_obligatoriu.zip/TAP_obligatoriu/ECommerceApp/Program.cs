﻿using ECommerceApp;

// 1. Catalog
var laptop = new Product { Name = "Laptop", Price = 4500 };
var mouse = new Product { Name = "Mouse", Price = 150 };

// 2. Coș
var cart = new ShoppingCart();
cart.AddProduct(laptop, 1);
cart.AddProduct(mouse, 2);

// 3. Comandă
var order = new Order(cart);
order.Checkout(new CreditCardPayment(), new DhlShipping(), new NoDiscount());