namespace ECommerceApp;


public interface IPaymentStrategy { void Pay(decimal amount); }
public class CreditCardPayment : IPaymentStrategy { 
    public void Pay(decimal amount) => Console.WriteLine($"Plătit {amount} RON prin Credit Card."); 
}


public interface IShippingStrategy { decimal GetCost(); void Ship(); }
public class DhlShipping : IShippingStrategy { 
    public decimal GetCost() => 25m; 
    public void Ship() => Console.WriteLine("Expediat prin DHL."); 
}


public interface IDiscountStrategy { decimal Apply(decimal amount); }
public class NoDiscount : IDiscountStrategy { public decimal Apply(decimal amount) => amount; }