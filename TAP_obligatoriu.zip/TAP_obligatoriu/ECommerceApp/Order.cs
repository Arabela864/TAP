namespace ECommerceApp;

public class Order {
    private readonly ShoppingCart _cart;
    public Order(ShoppingCart cart) => _cart = cart;

    public void Checkout(IPaymentStrategy pay, IShippingStrategy ship, IDiscountStrategy disc) {
        decimal basePrice = _cart.GetTotal();
        decimal finalPrice = disc.Apply(basePrice) + ship.GetCost();
        
        Console.WriteLine($"Total produse: {basePrice} RON");
        Console.WriteLine($"Total final: {finalPrice} RON");
        
        pay.Pay(finalPrice);
        ship.Ship();
    }
}