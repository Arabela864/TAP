using System.Collections.Generic;
using System.Linq;

namespace LibraryTracker.Business;

public class LibraryService
{
    private List<Book> _books = new List<Book>();

    public void AddBook(string title, string author)
    {
        _books.Add(new Book(title, author));
    }

    public List<Book> GetAllBooks()
    {
        return _books;
    }

    public void BorrowBook(string title)
    {
        var book = _books.FirstOrDefault(b => b.Title == title);

        if (book == null)
            throw new Exception("Book not found.");

        book.Borrow();
    }

    public List<Book> GetOverdueBooks(int days)
    {
        return _books.Where(b => b.IsOverdue(days)).ToList();
    }
}
