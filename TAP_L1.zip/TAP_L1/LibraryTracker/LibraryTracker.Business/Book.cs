﻿namespace LibraryTracker.Business;

public class Book
{
    public string Title { get; set; }
    public string Author { get; set; }
    public bool IsBorrowed { get; private set; }
    public DateTime? BorrowDate { get; private set; }

    public Book(string title, string author)
    {
        Title = title;
        Author = author;
        IsBorrowed = false;
        BorrowDate = null;
    }

    public void Borrow()
    {
        if (IsBorrowed)
            throw new InvalidOperationException("Book already borrowed.");

        IsBorrowed = true;
        BorrowDate = DateTime.Now;
    }

    public void Return()
    {
        IsBorrowed = false;
        BorrowDate = null;
    }

    public bool IsOverdue(int days)
    {
        if (!IsBorrowed || BorrowDate == null)
            return false;

        return BorrowDate.Value.AddDays(days) < DateTime.Now;
    }
}
