﻿using LibraryTracker.Business;

var library = new LibraryService();

while (true)
{
    Console.WriteLine("\nLibrary Tracker Menu");
    Console.WriteLine("1. Add Book");
    Console.WriteLine("2. List Books");
    Console.WriteLine("3. Borrow Book");
    Console.WriteLine("4. Get Overdue Books (7 days)");
    Console.WriteLine("5. Exit");

    Console.Write("Choice: ");
    var choice = Console.ReadLine();

    try
    {
        switch (choice)
        {
            case "1":
                Console.Write("Title: ");
                var title = Console.ReadLine()!;
                Console.Write("Author: ");
                var author = Console.ReadLine()!;
                library.AddBook(title, author);
                Console.WriteLine("Book added successfully.");
                break;

            case "2":
                var books = library.GetAllBooks();
                if (!books.Any())
                {
                    Console.WriteLine("No books available.");
                }
                else
                {
                    Console.WriteLine("\nBooks in library:");
                    foreach (var book in books)
                    {
                        Console.WriteLine($"{book.Title} by {book.Author} - Borrowed: {book.IsBorrowed}");
                    }
                }
                break;

            case "3":
                Console.Write("Enter title to borrow: ");
                var borrowTitle = Console.ReadLine()!;
                library.BorrowBook(borrowTitle);
                Console.WriteLine("Book borrowed successfully.");
                break;

            case "4":
                var overdue = library.GetOverdueBooks(7);
                if (!overdue.Any())
                {
                    Console.WriteLine("No overdue books.");
                }
                else
                {
                    Console.WriteLine("\nOverdue books:");
                    foreach (var book in overdue)
                    {
                        Console.WriteLine($"{book.Title} by {book.Author} is overdue!");
                    }
                }
                break;

            case "5":
                return;

            default:
                Console.WriteLine("Invalid option. Try again.");
                break;
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error: {ex.Message}");
    }
}
